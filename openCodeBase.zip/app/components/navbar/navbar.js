console.log('navbar on');

const NAVBAR = document.createElement('h1');
NAVBAR.id = 'NAVBAR';
document.body.appendChild(NAVBAR);
