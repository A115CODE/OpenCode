console.log('view on');

const VIEW = document.createElement('div');
VIEW.id = 'VIEW';
document.body.appendChild(VIEW);
